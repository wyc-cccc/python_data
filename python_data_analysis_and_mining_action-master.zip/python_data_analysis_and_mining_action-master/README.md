# Python 数据分析与挖掘实战 带注释源码

![](https://img3.doubanio.com/view/subject/l/public/s28376942.jpg)

> 原书：[Python 数据分析与挖掘实战](https://book.douban.com/subject/26677686/)
> 
> 贡献者：[wnma3mz](https://github.com/wnma3mz)
> 
> 欢迎任何人参与和完善：一个人可以走的很快，但是一群人却可以走的更远。

+   [ApacheCN 机器学习交流群 629470233](http://shang.qq.com/wpa/qunwpa?idkey=30e5f1123a79867570f665aa3a483ca404b1c3f77737bc01ec520ed5f078ddef)
+   [ApacheCN 学习资源](http://www.apachecn.org/)

&zwj;

+ [在线阅读](https://www.gitbook.com/book/wizardforcel/ppdam-code-notes/details)
+ [PDF格式](https://www.gitbook.com/download/pdf/book/wizardforcel/ppdam-code-notes)
+ [EPUB格式](https://www.gitbook.com/download/epub/book/wizardforcel/ppdam-code-notes)
+ [MOBI格式](https://www.gitbook.com/download/mobi/book/wizardforcel/ppdam-code-notes)
+ [代码仓库](https://github.com/apachecn/python_data_analysis_and_mining_action)

## 章节

每个`chapter`表示章节

- `code.py`: 代码
- `date/`: 数据文件
- `tmp/`: 生成数据文件
